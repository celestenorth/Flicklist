=======
imdbapi
=======

imdbapi is a web-based script that parses the IMDB datafiles and exposes
an API to retrieve information from them.

Dependencies
------------

To run imdbapi, you need the `bottle framework <http://bottle.paws.de/>`_
and the `SQLAlchemy ORM <http://www.sqlalchemy.org/>`_.

License
-------

imdbapi is made available under the GPL (version 3 or later).

